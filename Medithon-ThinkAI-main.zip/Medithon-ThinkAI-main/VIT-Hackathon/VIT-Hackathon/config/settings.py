class Settings:
    DEFAULT_PAGE = 'home'
    DEFAULT_THEME = 'light'
